import time
import random 
from rooms import rooms
# importing my tools file for clean code
from my_tools import clean_console, help_menu, show_map, save_my_game, load_my_game, run_frequency_game

# --- GLOBAL VARIABLES ---
# setting up player stats
player = {
    "char": None, 
    "energy": 2,
    "bag": [],
    "notes": [],
    "location": "Throne Room",
    "timer": 360, # 6 hours in game minutes
    "is_game_over": False
}

# --- GAME FUNCTIONS ---

def randomize_safe_code():
    # Code generation logic
    code = random.randint(1000, 9999)
    code_str = str(code)

    # Update the safe
    rooms["Library"]["safe"]["code"] = code_str
    # Split code for clues
    first_two = code_str[0:2]
    last_two = code_str[2:4]
    # Chef gets the first half
    new_secret = "FINE! I saw Lady Elara. She was mumbling about the numbers '" + first_two + "...'"
    rooms["Kitchen"]["npc"]["secret"] = new_secret
    # Throne Room gets the second half
    rooms["Throne Room"]["lens_clue"] = "The plaque says 'EST. " + last_two + "'. That completes the code."
    rooms["Throne Room"]["description"] += " A plaque on the armrest reads 'EST. " + last_two + "'."
def wait(mins):
    # lowers the timer and checks game over
    player["timer"] = player["timer"] - mins
    
    if player["timer"] <= 0:
        clean_console()
        print("!!! TIME IS UP !!!")
        print("The Aether Core exploded. The manor is destroyed.")
        player["is_game_over"] = True
        return True
    return False

def check_end_game():
    if player["location"] != "Throne Room":
        print("You need to be in the Throne Room to accuse someone.")
        return
    
    # Check if we have the core
    if "Aether Core" not in player["bag"]:
        print("LORD KALDRIC: 'Find the Core first! I am dying!'")
        return
    
    clean_console()
    print("--- THE FINAL DECISION ---")
    print("You place the Core in Kaldric's chest.")
    print("He looks stronger. He asks: 'Who stole it?'")
    print("1. Chef Gorn")
    print("2. Lady Elara")
    print("3. Butler James")
    
    # Secret Ending Option
    if "Secret Diary" in player["bag"]:
        print("4. [SECRET] Destroy the Core")
        
    ans = input("Pick a number: ")
    
    if ans == "1":
        print("Wrong. The Chef is innocent. Kaldric executes him.")
        print("BAD ENDING")
    elif ans == "2":
        print("Correct! She stole it to stop Kaldric's evil experiments.")
        print("She is arrested. Kaldric continues his dark work.")
        print("NEUTRAL ENDING")
    elif ans == "3":
        print("Wrong. James is loyal.")
        print("FIRED ENDING")
    elif ans == "4" and "Secret Diary" in player["bag"]:
        print("You smash the Core on the ground!")
        print("Kaldric screams as his power fades.")
        print("You saved the world from his dangerous machines.")
        print("TRUE HERO ENDING")
    else:
        print("You didn't pick a valid person.")
    
    player["is_game_over"] = True
    input("Press Enter to exit...")

def read_notes():
    print("\n--- MY JOURNAL ---")
    if len(player["notes"]) == 0:
        print("No notes yet.")
    else:
        for n in player["notes"]:
            print("- " + n)
    # If we have the diary, we can read it here
    if "Secret Diary" in player["bag"]:
        print("\n[SECRET DIARY ENTRIES]")
        print("'Project Ironheart is a mistake. Kaldric wants to replace")
        print("human hearts with engines. I must steal the Core to stop him.'")
        print("- Signed, Lady Elara")

def swap_char():
    if player["char"] == "Silas":
        player["char"] = "Kaelen"
        print("Switched to KAELEN (The Listener)")
    else:
        player["char"] = "Silas"
        print("Switched to SILAS (The Observer)")
def silas_ability():
    if player["char"] != "Silas":
        print("Only Silas can use the Specter Lens.")
        return
    if player["energy"] > 0:
        player["energy"] -= 1
        wait(5)
        print("Using Specter Lens...")
        clue = rooms[player["location"]]['lens_clue']
        print("CLUE: " + clue)
    else:
        print("No batteries left. Search rooms for batteries.")

def kaelen_ability():
    if player["char"] != "Kaelen":
        print("Only Kaelen can listen carefully.")
        return
    wait(5)
    print("Listening...")
    time.sleep(1)
    current_room = rooms[player["location"]]
    # 1. Listen to NPC
    if current_room["npc"] != None:
        person = current_room["npc"]
        # If they have a secret, Kaelen hears the heartbeat spike
        if person['secret']:
            print("HEARTBEAT SPIKE! They are lying.")
            print("You hear them whisper: '" + person['secret'] + "'")
            note = person['name'] + " secret: " + person['secret']
            
            if note not in player["notes"]:
                player["notes"].append(note)
                print("(Added to Journal)")
            return
            
     # 2. Listen to Room
    print("Heard: " + current_room['sound_clue'])
def solve_levers():
    print("\n--- SECURITY SYSTEM: PHASE 1 ---")
    print("The Cage is locked by 3 colored levers.")
    print("Recall the painting in the Library...")
    attempt = input("First lever (red/green/blue): ").lower()
    if attempt == "blue":
        print("Click. First lock opens.")
        attempt2 = input("Second lever: ").lower()
        if attempt2 == "red":
            print("Clank. Second lock opens.")
            attempt3 = input("Third lever: ").lower()
            if attempt3 == "green":
                print("Mechanical locks disengaged...")
                time.sleep(1)
                # Phase 2: Frequency Game
                print("\n--- SECURITY SYSTEM: PHASE 2 ---")
                print("Digital Lock Activated! Sync the frequency!")
                success = run_frequency_game()
                if success == True:
                    print("SYSTEM ACCEPTED. The cage opens!")
                    rooms["Workshop"]["cage_locked"] = False
                    return
                else:
                    print("SYSTEM ERROR! Resetting...")
                    wait(10)
                    return

    print("BUZZZ! Wrong order! The system resets.")
    wait(5)

def do_search():
    wait(5)
    current_room = rooms[player["location"]]
    print("Searching " + player["location"] + "...")
    time.sleep(1)
    # Special Case: Workshop Cage
    if player["location"] == "Workshop" and current_room["cage_locked"]:
        print("You see the Aether Core, but it's inside a locked cage.")
        ans = input("Do you want to try the levers? (yes/no): ").lower()
        if ans == "yes":
            solve_levers()
        if current_room["cage_locked"]:
            # If still locked, we can't get the item
            return 

    # Safe System
    if "safe" in current_room:
        my_safe = current_room["safe"]
        if my_safe["locked"] == True:
            print("Found a locked safe.")
            code = input("Enter 4-digit code: ")
            if code == my_safe["code"]:
                print("Click! Opened! Found batteries.")
                player["energy"] += my_safe["reward"]
                my_safe["locked"] = False
            else:
                print("Wrong code.")
    # Item System
    item = current_room["item"]
    if item:
        if item == "Battery":
            player["energy"] += 1
            print("You found a Battery.")
            current_room["item"] = None # Remove item
        else:
            if item not in player["bag"]:
                player["bag"].append(item)
                print("You found: " + item)
                current_room["item"] = None
    else:
        print("Found nothing else of interest.")
def talk_npc():
    current_room = rooms[player["location"]]
    if current_room["npc"]:
        wait(5)
        npc = current_room["npc"]
        print(npc["name"] + ": " + npc["dialogue"])
        # PUZZLE
        if npc["name"] == "Chef Gorn":
            if npc["riddle_solved"] == False:
                print("\nCHEF: 'Wait! I need an ingredient. It has eyes but cannot see. What is it?'")
                ans = input("Answer: ").lower()
                if "potato" in ans:
                    print("CHEF: 'Yes! Potatoes! Here, take this old key I found.'")
                    npc["riddle_solved"] = True
                    player["bag"].append("Rusty Key")
                    print("[!] You got the Rusty Key.")
                else:
                    print("CHEF: 'No! Get out of my kitchen!'")
    else:
        print("There is no one here.")
def move(direction):
    current_room = rooms[player["location"]]
    # check if exit exists
    if direction in current_room["exits"]:
        next_room_name = current_room["exits"][direction]
        next_room_data = rooms[next_room_name]
        
        # Check if door is locked
        if next_room_data["locked"] == True:
            if "Rusty Key" in player["bag"]:
                print("Unlocking door with Rusty Key...")
                next_room_data["locked"] = False
                wait(5)
                player["location"] = next_room_name
            else:
                print("The door is locked. You need a key.")
        else:
            wait(5)
            player["location"] = next_room_name
            print("You went " + direction)
    else:
        print("You can't go that way.")
def show_status():
    print("\n=========================")
    print("LOCATION: " + player['location'])
    print("CHARACTER: " + player['char'])
    print("TIME LEFT: " + str(player['timer']) + " mins")
    if player['char'] == "Silas":
        print("ENERGY: " + str(player['energy']))
    print("=========================")
    print(rooms[player['location']]["description"])
    print("[Type 'help' for commands]")

def start_game():
    clean_console()
    # Randomize the game elements
    randomize_safe_code()
    
    print("MYSTERY OF IRONHEART MANOR")
    print("--------------------------")
    time.sleep(1)
    print("Select your Investigator:")
    print("1. Silas (The Eye) - Can see hidden clues.")
    print("2. Kaelen (The Ear) - Can hear lies and noises.")
    while True:
        x = input("Pick character (1 or 2): ")
        if x == "1":
            player["char"] = "Silas"
            break
        elif x == "2":
            player["char"] = "Kaelen"
            break
            
    print("\nLord Kaldric: 'My Aether Core was stolen. Find it in 6 hours or the manor explodes.'")
    input("Press Enter to start investigation...")
    clean_console()

# --- MAIN LOOP ---
start_game()

while player['is_game_over'] == False:
    show_status()
    user_input = input("> ").lower().split()
    
    if len(user_input) == 0:
        continue
    cmd = user_input[0]
    if cmd == "go":
        if len(user_input) > 1:
            move(user_input[1])
        else:
            print("Go where? (north, south, east, west)")
    elif cmd == "map":
        show_map(player["location"])
    elif cmd == "search":
        do_search()
    elif cmd == "lens":
        silas_ability()   
    elif cmd == "listen":
        kaelen_ability()   
    elif cmd == "switch":
        swap_char()     
    elif cmd == "talk":
        talk_npc()   
    elif cmd == "journal":
        read_notes()   
    elif cmd == "save":
        save_my_game(player, rooms)
    elif cmd == "load":
        loaded = load_my_game()
        if loaded:
            player = loaded["player"]
            rooms.update(loaded["world"])
            print("Game Loaded.")
    elif cmd == "accuse":
        check_end_game()
    elif cmd == "help":
        help_menu()
    elif cmd == "quit":
        print("Goodbye.")
        break
    else:
        print("I don't understand that command.")
#############################################
 # FASTEST PLAY         -->>  Go North(Hallway) -->> Go East(Kitchen) -->> Talk(Chef Gorn) -->> Ans(Potato)  -->> Go West(Hallway)  -->> Go West(Library) -->> Search(u'll find Secret Diary for the 4. end)
 #  -->> Go East(Hallway) -->> Go North(Workshop) -->> Search (Do you want to try levers?) -->> Yes -->>Blue Red Green   -->> make the puzzle  -->> Go south(Hallway) -->> Go South(Throne Room) -->> Accuse (4) YOU MADE IT TO THE TRUE HERO ENDING
