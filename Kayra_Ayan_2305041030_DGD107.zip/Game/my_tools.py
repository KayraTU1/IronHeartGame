import os
import sys
import time
import json
import random

# function to clean screen I found in Stack OverFlow
def clean_console():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def typing_print(text):
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.03) # speed of typing
    print()

def run_frequency_game():
    print("\n--- FREQUENCY TUNING ---")
    print("Kaelen hears a complex signal...")
    print("Memorize the frequency number below!")
    time.sleep(1)
    secret_num = str(random.randint(1000, 9999))
    
    print("\n   [ " + secret_num + " ]   ")
    print("\n------------------------")
    
    time.sleep(3) 
    clean_console()
    print("\n--- FREQUENCY TUNING ---")
    print("Signal lost...")
    guess = input("Enter the frequency number: ")
    if guess == secret_num:
        print("SIGNAL LOCKED.")
        return True
    else:
        print("Signal failed. Static noise.")
        return False

def show_map(room_name):
    print("\n--------------------------------")
    print("--- IRONHEART MANOR MAP ---")
    you = "[ *YOU* ]"
    throne_m = "[ Throne Room ]"
    hall_m   = "[   Hallway   ]"
    kit_m    = "[   Kitchen   ]"
    lib_m    = "[   Library   ]"
    work_m   = "[  Workshop   ]"
    if room_name == "Throne Room": throne_m = you
    if room_name == "Hallway":     hall_m   = you
    if room_name == "Kitchen":     kit_m    = you
    if room_name == "Library":     lib_m    = you
    if room_name == "Workshop":    work_m   = you
    # Drawin map
    print("\n          " + work_m)
    print("               |")
    print(" " + lib_m + "-" + hall_m + "-" + kit_m)
    print("               |")
    print("          " + throne_m)
    print("\n--------------------------------")
    print("Exits: Check 'go [direction]'")
def save_my_game(data, room_data):
    stuff_to_save = { "player": data, "world": room_data }
    try:
        f = open("savefile.json", "w")
        json.dump(stuff_to_save, f)
        f.close()
        print("Game saved.")
    except:
        print("Error saving.")

def load_my_game():
    try:
        f = open("savefile.json", "r")
        data = json.load(f)
        f.close()
        print("Game loaded.")
        return data
    except:
        print("No save file found.")
        return None

def help_menu():
    print("\n--- COMMANDS ---")
    print("save   -> Save game")
    print("load   -> Load game")
    print("quit   -> Exit")
    print("go [dir] -> Move")
    print("map    -> See map")
    print("search -> Look for items")
    print("repair -> Fix items (Workbench)")
    print("talk   -> Talk to people")
    print("ask [place] -> Ask directions")
    print("journal-> Read notes")
    print("lens   -> Silas ability")
    print("listen -> Kaelen ability")
    print("switch -> Change character")