# This dictionary holds all the data for the game world
rooms = {
    "Throne Room": {
        "description": "You are in the Ironheart Throne Room. Lord Kaldric is frozen on his throne. There is a golden plaque on the armrest.",
        "lens_clue": "The plaque says 'EST. 99'. Wait, that looks like the end of a code.",
        "sound_clue": "The machine goes click... wheeze... click.",
        "item": None,
        "exits": {"north": "Hallway"},
        "locked": False,
        "npc": {
            "name": "Butler James",
            "dialogue": "Oh heavens! The Master froze! I heard Lady Elara screaming that 'The Engine is a curse!' before she ran off.",
            "secret": "I confess! I didn't oil the machine. But I didn't steal the Core!" 
        }
    },
    "Hallway": {
        "description": "A dark corridor. Kitchen is East, Library is West. The floor is vibrating.",
        "lens_clue": "Muddy footprints lead from the Garden into the Kitchen.",
        "sound_clue": "Scratching noises behind the Library wall.",
        "item": "Battery",
        "exits": {"south": "Throne Room", "east": "Kitchen", "west": "Library", "north": "Workshop"},
        "locked": False,
        "npc": None
    },
    "Kitchen": {
        "description": "The kitchen is in chaos. Pots are boiling over. It smells of burnt toast and fear.",
        "lens_clue": "The Chef's apron has fresh oil stains.",
        "sound_clue": "The Chef's heart is beating super fast. THUMP THUMP.",
        "item": "Battery",
        "exits": {"west": "Hallway"},
        "locked": False,
        "npc": {
            "name": "Chef Gorn",
            "dialogue": "GET OUT! My soufflé is ruined! Unless... you can help me remember the recipe?",
            "secret": "FINE! I saw Lady Elara hiding something in the Library Safe! She was muttering numbers starting with...",
            "riddle_solved": False 
        }
    },
    "Library": {
        "description": "Ancient books everywhere. A strange painting depicts a 'Great Fall': A BLUE tear falling from a RED eye onto the GREEN grass.",
        "lens_clue": "A book called 'The History of Steam' has fingerprints on it.",
        "sound_clue": "There is a hollow echo behind the shelf.",
        "item": "Secret Diary", 
        "exits": {"east": "Hallway"},
        "locked": False,
        "npc": None,
        "safe": {
            "locked": True,
            "code": "0000", 
            "reward": 2
        }
    },
    "Workshop": {
        "description": "Lord Kaldric's work room. It is filled with steam.",
        "lens_clue": "Footprints go back to the Library... but the Core is locked in a cage.",
        "sound_clue": "Loud humming noise coming from the machine cage.",
        "item": "Aether Core",
        "exits": {"south": "Hallway"},
        "locked": True, 
        "npc": None,
        "cage_locked": True 
    }
}